[**CellSignal** - _Disentangling biological signal from experimental noise in cellular images_](https://www.rxrx.ai/)

https://www.kaggle.com/c/recursion-cellular-image-classification
