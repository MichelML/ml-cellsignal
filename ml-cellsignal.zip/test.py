print(1)
file = open("/artifacts/copy.txt", "w") 
file.write("Your text goes here") 
file.close() 
