#!/bin/bash
jupyter nbconvert --to script experiment13_cellline_tta.ipynb;
ipython experiment13_cellline_tta.py;
