#!/bin/bash
jupyter nbconvert --to script experiment14.ipynb;
ipython experiment14.py;
